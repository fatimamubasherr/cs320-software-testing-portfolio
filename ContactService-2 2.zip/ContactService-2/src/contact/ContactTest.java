package contact;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ContactTest {

    @Test
    public void testValidContactCreation() {
        Contact contact = new Contact("12345", "Fatima", "Khan", "1234567890", "123 Main Street");

        assertEquals("12345", contact.getContactId());
        assertEquals("Fatima", contact.getFirstName());
        assertEquals("Khan", contact.getLastName());
        assertEquals("1234567890", contact.getPhone());
        assertEquals("123 Main Street", contact.getAddress());
    }

    @Test
    public void testContactIdCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact(null, "Fatima", "Khan", "1234567890", "123 Main Street");
        });
    }

    @Test
    public void testContactIdCannotBeLongerThan10() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345678901", "Fatima", "Khan", "1234567890", "123 Main Street");
        });
    }

    @Test
    public void testFirstNameCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", null, "Khan", "1234567890", "123 Main Street");
        });
    }

    @Test
    public void testFirstNameCannotBeLongerThan10() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "VeryLongName", "Khan", "1234567890", "123 Main Street");
        });
    }

    @Test
    public void testLastNameCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Fatima", null, "1234567890", "123 Main Street");
        });
    }

    @Test
    public void testLastNameCannotBeLongerThan10() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Fatima", "VeryLongLast", "1234567890", "123 Main Street");
        });
    }

    @Test
    public void testPhoneCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Fatima", "Khan", null, "123 Main Street");
        });
    }

    @Test
    public void testPhoneMustBeExactly10Digits() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Fatima", "Khan", "12345", "123 Main Street");
        });

        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Fatima", "Khan", "123456789A", "123 Main Street");
        });
    }

    @Test
    public void testAddressCannotBeNull() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Fatima", "Khan", "1234567890", null);
        });
    }

    @Test
    public void testAddressCannotBeLongerThan30() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Fatima", "Khan", "1234567890",
                    "1234567890123456789012345678901");
        });
    }

    @Test
    public void testUpdateFirstName() {
        Contact contact = new Contact("12345", "Fatima", "Khan", "1234567890", "123 Main Street");
        contact.setFirstName("Ayesha");
        assertEquals("Ayesha", contact.getFirstName());
    }

    @Test
    public void testUpdateLastName() {
        Contact contact = new Contact("12345", "Fatima", "Khan", "1234567890", "123 Main Street");
        contact.setLastName("Ali");
        assertEquals("Ali", contact.getLastName());
    }

    @Test
    public void testUpdatePhone() {
        Contact contact = new Contact("12345", "Fatima", "Khan", "1234567890", "123 Main Street");
        contact.setPhone("0987654321");
        assertEquals("0987654321", contact.getPhone());
    }

    @Test
    public void testUpdateAddress() {
        Contact contact = new Contact("12345", "Fatima", "Khan", "1234567890", "123 Main Street");
        contact.setAddress("456 Park Avenue");
        assertEquals("456 Park Avenue", contact.getAddress());
    }
}
