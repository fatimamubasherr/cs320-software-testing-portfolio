package contact;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ContactServiceTest {

    @Test
    public void testAddContact() {
        ContactService service = new ContactService();
        Contact contact = new Contact("12345", "Fatima", "Khan", "1234567890", "123 Main Street");

        service.addContact(contact);

        assertNotNull(service.getContact("12345"));
        assertEquals("Fatima", service.getContact("12345").getFirstName());
    }

    @Test
    public void testAddDuplicateContactIdFails() {
        ContactService service = new ContactService();
        Contact contact1 = new Contact("12345", "Fatima", "Khan", "1234567890", "123 Main Street");
        Contact contact2 = new Contact("12345", "Ayesha", "Ali", "0987654321", "456 Park Avenue");

        service.addContact(contact1);

        assertThrows(IllegalArgumentException.class, () -> {
            service.addContact(contact2);
        });
    }

    @Test
    public void testDeleteContact() {
        ContactService service = new ContactService();
        Contact contact = new Contact("12345", "Fatima", "Khan", "1234567890", "123 Main Street");

        service.addContact(contact);
        service.deleteContact("12345");

        assertNull(service.getContact("12345"));
    }

    @Test
    public void testDeleteNonexistentContactFails() {
        ContactService service = new ContactService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteContact("99999");
        });
    }

    @Test
    public void testUpdateFirstName() {
        ContactService service = new ContactService();
        Contact contact = new Contact("12345", "Fatima", "Khan", "1234567890", "123 Main Street");

        service.addContact(contact);
        service.updateFirstName("12345", "Ayesha");

        assertEquals("Ayesha", service.getContact("12345").getFirstName());
    }

    @Test
    public void testUpdateLastName() {
        ContactService service = new ContactService();
        Contact contact = new Contact("12345", "Fatima", "Khan", "1234567890", "123 Main Street");

        service.addContact(contact);
        service.updateLastName("12345", "Ali");

        assertEquals("Ali", service.getContact("12345").getLastName());
    }

    @Test
    public void testUpdatePhone() {
        ContactService service = new ContactService();
        Contact contact = new Contact("12345", "Fatima", "Khan", "1234567890", "123 Main Street");

        service.addContact(contact);
        service.updatePhone("12345", "0987654321");

        assertEquals("0987654321", service.getContact("12345").getPhone());
    }

    @Test
    public void testUpdateAddress() {
        ContactService service = new ContactService();
        Contact contact = new Contact("12345", "Fatima", "Khan", "1234567890", "123 Main Street");

        service.addContact(contact);
        service.updateAddress("12345", "456 Park Avenue");

        assertEquals("456 Park Avenue", service.getContact("12345").getAddress());
    }

    @Test
    public void testUpdateNonexistentContactFails() {
        ContactService service = new ContactService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.updateFirstName("99999", "Ayesha");
        });
    }
}
